import { SetQuestion } from './SetQuestion'

export default SetQuestion
