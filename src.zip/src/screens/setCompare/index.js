import SetCompare from './SetCompare';

export default SetCompare;
